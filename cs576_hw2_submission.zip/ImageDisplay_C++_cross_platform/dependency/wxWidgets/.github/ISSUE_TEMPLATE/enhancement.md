---
name: Enhancement
about: Propose a new feature or enhancement of an existing one
title: ''
labels: 'feature'
assignees: ''

---

<!--

Implementation ideas and helpful links, e.g. to platform-specific API that can
be used, are welcome.

Please mention if you propose to submit pull requests implementing this.

-->

### Description
<!-- Describe the proposed addition here -->
